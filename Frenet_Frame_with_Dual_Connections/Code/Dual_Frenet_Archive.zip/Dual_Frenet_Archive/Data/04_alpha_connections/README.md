# Dataset 04: alpha-Frenet geometric diagnostics

Calculated on 16 November 2026. [results.json](results.json) contains the 18 time/alpha/step cases, calculated matrices, curvature, separate residuals, difference-step comparison, environment, and the explicit positive nonmetric example.

The categorical nonzero-alpha cases fail normality and are not feasible normal-pair solution records. They demonstrate that alpha-connection duality and shared-tangent Frenet construction do not automatically imply the extra normality hypothesis. The alpha-zero and positive nonmetric examples supply consistency controls.

This dataset uses JSON rather than the shared solution NPZ schema. See [Methodology.md](../../Surveys/04_alpha_connections/Methodology.md), [Results.md](../../Surveys/04_alpha_connections/Results.md), and the [information-geometry note](../../docs/Information_Geometry.md) before comparing its diagnostic matrices with the solution datasets.
