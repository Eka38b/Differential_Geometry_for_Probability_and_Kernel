# Data guide

This directory holds the reusable numerical records for the MathOverflow finiteness problem. The first three datasets contain saved approximate solutions with fixed diagonal lists, strictly positive superdiagonals, orthogonal overlap fixing the first coordinate, and a skew source annihilating that coordinate. Dataset 04 contains geometric diagnostics and is not a table of feasible normal-pair solutions.

## Find an input

| Location | Contents |
| --- | --- |
| [index.csv](index.csv) | One row per retained fixed input in datasets 01–03, with the NPZ path, dimension, affine dimension, source flag, and saved root count |
| [01_zero_source/](01_zero_source/README.md) | 69 historical zero-source inputs and 83 saved root occurrences |
| [02_magnitude/](02_magnitude/README.md) | 122 historical inputs, 127 saved root occurrences, and exact magnitude counterexamples |
| [03_shared_tangent_source/](03_shared_tangent_source/README.md) | 40 new nonzero-source inputs, all satisfying the shared-tangent restriction |
| [04_alpha_connections/](04_alpha_connections/README.md) | 18 calculated alpha-Frenet diagnostics and a separate positive example |
| [validation.json](validation.json) | Independent full-equation audit of all saved pairs in datasets 01–03 |
| [markdown_validation.json](markdown_validation.json) | README/note source checks for links, macro use, braces, and subscripts |

Start with a survey's `summary.csv` for tabular inspection, its `results.json` for solver history, and an `inputs/*.npz` file for actual matrices. The index uses paths relative to this `Data` directory. Root occurrences across separate fixed inputs are counted separately.

## Shared NPZ schema for datasets 01–03

| Field | Shape | Meaning |
| --- | --- | --- |
| `C`, `S` | `(n,n)` | Frozen overlap matrix and source |
| `d`, `dstar` | `(n,)` | Frozen diagonal lists |
| `a`, `astar` | `(n-1,)` | Frozen positive superdiagonal lists |
| `D0`, `E0` | `(n,n)` | Compatible witness or affine-center matrices; their upper parts specify the fixed entries |
| `basis` | `(r,n,n)` | Frobenius-orthonormal basis for the allowed lower perturbations after linear elimination |
| `roots`, `dual_roots` | `(k,n,n)` | Saved paired matrices in matching order |
| `linear_singular_values` | `(m,)` | Singular values used for the recorded affine reduction |

The diagonal of `D0` or `E0` must agree with the explicit diagonal arrays. All fixed upper entries, including Hessenberg zeros, are preserved. Dataset 03's basis also includes the linear source-commutation constraint needed for simultaneous normality.

For example, from the archive root:

```python
from pathlib import Path
import numpy as np

path = next(Path('Data/03_shared_tangent_source/inputs').glob('*.npz'))
with np.load(path, allow_pickle=False) as data:
    C, S = data['C'], data['S']
    D, E = data['roots'][0], data['dual_roots'][0]
    print(np.linalg.norm(D.T + C @ E @ C.T - S))
    print(np.linalg.norm(S[:, 0]))
```

## Numerical and exact records

NPZ matrices are floating-point approximations. Numerical compatibility means satisfaction of the recorded tolerances; it is not an exact existence certificate for arbitrary rounded data. The rational boxes and polynomial systems in [02_magnitude/certificates/](02_magnitude/certificates/) define exact algebraic inputs and solutions for the certified examples. Do not substitute rounded matrix decimals into an exact theorem.

Failed generation and synthesis records are labeled separately. Their iterates are not stored among accepted solution inputs. Supplied witnesses and analytic controls are distinguished from additional numerical discoveries in the detailed results.

## Audit and regeneration

```bash
python Code/audit_data.py
python Code/certify_counterexamples.py --out Data/02_magnitude/certificates --verify-only
```

Replay commands in each survey README write to a user-selected output directory. The archived historical results remain available for comparison. See the corresponding methodology document before interpreting root counts, rank tests, or geometry diagnostics.
