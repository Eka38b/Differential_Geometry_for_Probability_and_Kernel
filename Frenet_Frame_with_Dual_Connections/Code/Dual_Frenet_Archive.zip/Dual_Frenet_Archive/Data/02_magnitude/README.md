# Dataset 02: magnitude multiplicity and certificates

Recorded on 7 November 2026; curated and verified on 16 November 2026. The dataset retains 122 fixed inputs, 127 saved root occurrences, 10,496 local multistart calls, and 576 implemented projected-homotopy paths. All accepted inputs satisfy the positive-superdiagonal, fixed-diagonal, zero-source specialization of the MathOverflow problem to numerical tolerance.

| File or directory | Use |
| --- | --- |
| [summary.csv](summary.csv) | Compact per-input results |
| [results.json](results.json) | Method recoveries, root origins, magnitude gaps, ranks, and spectral metadata |
| `inputs/*.npz` | Frozen matrices, affine bases, and saved paired roots |
| [certificates/certificate_n6.json](certificates/certificate_n6.json) | Rational box, polynomial equations, inverse, and isolation data for dimension 6 |
| [certificates/certificate_n8.json](certificates/certificate_n8.json) | Corresponding exact data for dimension 8 |
| [certificates/verification_summary.json](certificates/verification_summary.json) | Recomputed exact verification outcomes |
| `certificates/counterexample_n*.npz` | Convenient decimal approximations of the certified solution pairs |
| [generation_attempts.json](generation_attempts.json) | Recorded failed spectral-moment witness constructions |
| [synthesis_attempts.json](synthesis_attempts.json) | Paired-construction diagnostics, including unsuccessful attempts |

Exact data are defined by polynomial equations and rational isolating boxes, not by NPZ rounding. Both examples have two certified isolated solutions of different entry magnitudes with identical fixed data. This disproves magnitude uniqueness and leaves the finiteness question open.

See the [shared schema](../README.md), [methodology](../../Surveys/02_magnitude/Methodology.md), and [results](../../Surveys/02_magnitude/Results.md).
