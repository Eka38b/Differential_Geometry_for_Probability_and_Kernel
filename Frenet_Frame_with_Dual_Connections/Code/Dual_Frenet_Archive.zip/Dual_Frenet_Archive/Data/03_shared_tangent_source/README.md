# Dataset 03: nonzero shared-tangent sources

Generated and searched on 16 November 2026. All 40 fixed inputs have a nonzero skew source satisfying $Se_{1}=0$, positive superdiagonals, and fixed diagonal lists. The witnesses are skew-tridiagonal normal matrices; the unknown solutions are not restricted to skew matrices.

| File | Use |
| --- | --- |
| [summary.csv](summary.csv) | Dimensions, affine dimensions, source and pivot diagnostics, and saved root counts |
| [results.json](results.json) | Seeds, four overlap constructions, solver calls, root origins, rank sweeps, and residuals |
| `inputs/*.npz` | Frozen data, source-aware affine bases, and saved paired roots |

Six inputs have positive affine dimension, and their 144 local solver calls found no additional root beyond the supplied witnesses. The other 34 inputs already have zero affine dimension. These selected families do not establish general uniqueness or finiteness.

See the [shared schema](../README.md), [methodology](../../Surveys/03_shared_tangent_source/Methodology.md), and [results](../../Surveys/03_shared_tangent_source/Results.md).
