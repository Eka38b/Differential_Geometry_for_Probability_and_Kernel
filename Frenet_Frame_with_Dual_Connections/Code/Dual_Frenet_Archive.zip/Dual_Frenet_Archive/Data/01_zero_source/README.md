# Dataset 01: zero-source fixed inputs

Recorded on 7 November 2026; curated to the MathOverflow assumptions on 16 November 2026. There are 69 fixed inputs, 83 saved root occurrences, and 2,176 recorded multistart calls. All superdiagonals are positive, both diagonal lists are fixed, and every source is zero.

| File | Use |
| --- | --- |
| [summary.csv](summary.csv) | Compact per-input results |
| [results.json](results.json) | Historical methods, root origins, rank diagnostics, construction metadata, and search budgets |
| `inputs/*.npz` | Frozen data, affine basis, saved roots, and paired dual matrices |

See the [shared NPZ schema](../README.md), [methodology](../../Surveys/01_zero_source/Methodology.md), and [results interpretation](../../Surveys/01_zero_source/Results.md). The saved control roots include exact analytic cases, but arbitrary rounded NPZ data are numerical approximations. The dataset does not claim exhaustive classification of every numerical fiber.
