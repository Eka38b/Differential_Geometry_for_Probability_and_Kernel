# Survey 02: multiple solutions with different magnitudes

This study examines multiplicity within the zero-source specialization of the MathOverflow problem. It uses alternative numerical algorithms and exact certificates to test whether all solutions with the same fixed data must have the same entrywise magnitudes.

The retained historical dataset contains 122 fixed inputs and 127 saved root occurrences. Exact certificates in dimensions 6 and 8 show that the proposed magnitude-uniqueness property fails. Finiteness is not disproved.

See [Methodology.md](Methodology.md), [Results.md](Results.md), and [Data/02_magnitude/](../../Data/02_magnitude/README.md).

From the archive root:

```bash
python Code/certify_counterexamples.py --out Data/02_magnitude/certificates --verify-only
python Surveys/02_magnitude/run.py --out Reproduced/02 --starts 24 --limit 5 --alternative
```

The alternative flag enables the included zero-source univariate and projected-homotopy methods in addition to the two local least-squares algorithms. Exact certificates define the algebraic examples; rounded NPZ matrices are convenient approximations.
