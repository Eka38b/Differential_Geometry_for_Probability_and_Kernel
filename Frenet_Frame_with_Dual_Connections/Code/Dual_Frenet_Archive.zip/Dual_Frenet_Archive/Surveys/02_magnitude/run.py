"""Replay the curated frozen inputs. Pass --out to choose a new output directory."""
import subprocess,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
if __name__=='__main__':
    subprocess.run([sys.executable,str(ROOT/'Code/replay.py'),'--survey','02_magnitude',*sys.argv[1:]],check=True)
