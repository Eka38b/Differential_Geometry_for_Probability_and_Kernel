"""Generate and search compatible nonzero-source inputs for MathOverflow 516790."""
import argparse,csv,json,platform,sys
from pathlib import Path
import numpy as np
import scipy
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'Code'))
from fiber import Fiber,solve,save_case


def construct(n,seed,kind):
    rng=np.random.default_rng(seed);a=rng.uniform(.5,1.5,n-1)
    d=np.diag(a,1)-np.diag(a,-1)
    m=n-2
    if kind=='rotation':
        q,r=np.linalg.qr(rng.normal(size=(m,m)));q=q@np.diag(np.where(np.diag(r)>=0,1.,-1.))
    elif kind=='swap':
        q=np.eye(m);q[0,0]=q[-1,-1]=0.;q[0,-1]=q[-1,0]=1.
    else:
        v=rng.normal(size=m)
        if kind=='zero_pivot_reflection':v[0]=np.linalg.norm(v[1:])
        v/=np.linalg.norm(v);q=np.eye(m)-2*np.outer(v,v)
    c=np.eye(n);c[2:,2:]=q;s=-d+c@d@c.T
    return c,s,d


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--out',type=Path,required=True)
    ap.add_argument('--starts',type=int,default=24);args=ap.parse_args()
    args.out.mkdir(parents=True,exist_ok=True);rows=[]
    for n in [4,5,6,8,10]:
        for k,kind in enumerate(['reflection','zero_pivot_reflection','swap','rotation']):
            for j in range(2):
                seed=202611160+n*100+k*10+j
                c,s,d=construct(n,seed,kind)
                if np.linalg.norm(s)<1e-8:continue
                f=Fiber(c,s,d,d);roots,row=solve(f,args.starts,seed)
                case_id=f'{kind}_n{n}_s{j}'
                row.update(case_id=case_id,family=kind,n=n,seed=seed,
                           source_norm=float(np.linalg.norm(s)),source_tangent_norm=float(np.linalg.norm(s[:,0])),
                           minimum_abs_leading_minor=min(abs(float(np.linalg.det(c[:i,:i])))for i in range(1,n)),
                           minimum_superdiagonal=float(np.min(np.diag(d,1))),
                           data_file=f'inputs/{case_id}.npz')
                save_case(args.out/row['data_file'],f,roots);rows.append(row)
    result=dict(date='2026-11-16',scope='MathOverflow 516790; nonzero source; shared tangent; positive superdiagonals',
                supplied_witnesses=True,normality_search_starts=args.starts,
                versions=dict(python=platform.python_version(),numpy=np.__version__,scipy=scipy.__version__),rows=rows)
    (args.out/'results.json').write_text(json.dumps(result,indent=2)+'\n')
    fields=['case_id','family','n','affine_dimension','saved_root_count','source_norm','source_tangent_norm','minimum_abs_leading_minor','maximum_validation_error']
    with (args.out/'summary.csv').open('w')as out:
        w=csv.DictWriter(out,fieldnames=fields);w.writeheader()
        for row in rows:w.writerow({k:row[k]for k in fields})
    print(json.dumps(dict(inputs=len(rows),positive_affine_dimension=sum(x['affine_dimension']>0 for x in rows),
                         maximum_affine_dimension=max(x['affine_dimension']for x in rows),
                         solver_calls=sum(sum(x['solver_calls'].values())for x in rows),
                         root_occurrences=sum(x['saved_root_count']for x in rows),
                         singular_roots=sum(sum(t>0 for t in x['jacobian_nullities'])for x in rows),
                         maximum_validation_error=max(x['maximum_validation_error']for x in rows)),indent=2))


if __name__=='__main__':main()
