# Survey 03: nonzero sources with a shared tangent

This new survey was performed on 16 November 2026 for the MathOverflow problem itself. Every input satisfies $S\ne0$, $Se_{1}=0$, fixed diagonal lists, and positive superdiagonals. The source restriction is enforced by construction rather than checked only after a broad noncyclic search.

Read [Methodology.md](Methodology.md) for the construction and solver details, and [Results.md](Results.md) for the recorded outcomes. All 40 inputs and saved witnesses are available in [Data/03_shared_tangent_source/](../../Data/03_shared_tangent_source/README.md).

From the archive root:

```bash
python Surveys/03_shared_tangent_source/run.py --out Reproduced/03 --starts 24
```

The supplied compatible witnesses are included in the root count. Thirty-four inputs already have zero affine dimension after the linear constraints. The six remaining inputs provide the nontrivial local tests of normality; neither group proves general finiteness.
