"""Focused checks added 2026-11-16, separate from the historical matrix surveys.

Three-outcome categorical model in probability coordinates, sum(p)=1.
Frame rows are vector components. D[i,j]=g(nabla_T N_i,N_j).
Only frame derivatives use a five-point finite difference; p,p',p'' and T'
are analytic. This is a consistency check, not a finiteness experiment.
"""
import argparse
import json
from pathlib import Path
import platform

import numpy as np


def comm(a, b):
    return a @ b - b @ a


def curve(t):
    p = np.array([.25 + .1*t + .03*t*t, .35 - .04*t + .02*t*t,
                  .4 - .06*t - .05*t*t])
    v = np.array([.1 + .06*t, -.04 + .04*t, -.06 - .1*t])
    acc = np.array([.06, .04, -.1])
    return p, v, acc


def metric(p, x, y):
    return np.sum(x*y/p)


def connection_term(p, x, y, alpha):
    # alpha=-1 is the mixture connection; alpha=+1 is exponential.
    return (1+alpha)/2 * (metric(p, x, y)*p - x*y/p)


def frame(t, alpha):
    p, v, acc = curve(t)
    speed = np.sqrt(metric(p, v, v))
    speed_prime = (2*np.sum(v*acc/p)-np.sum(v**3/p**2))/(2*speed)
    tangent = v/speed
    tangent_prime = acc/speed - v*speed_prime/speed**2
    acceleration = tangent_prime/speed + connection_term(p, tangent, tangent, alpha)
    residual = acceleration-metric(p, acceleration, tangent)*tangent
    curvature = np.sqrt(metric(p, residual, residual))
    if curvature < 1e-9:
        raise ValueError('Degenerate Frenet residual')
    return np.stack([tangent, residual/curvature]), speed, curvature


def derivative(fun, t, h):
    return (fun(t-2*h)-8*fun(t-h)+8*fun(t+h)-fun(t+2*h))/(12*h)


def coefficients(t, frame_alpha, connection_alpha, h):
    p = curve(t)[0]
    n, speed, _ = frame(t, frame_alpha)
    ndot = derivative(lambda x: frame(x, frame_alpha)[0], t, h)/speed
    cov = np.stack([ndot[i]+connection_term(p, n[0], n[i], connection_alpha)
                    for i in range(2)])
    return (cov/p) @ n.T


def overlap(t, alpha):
    p = curve(t)[0]
    return (frame(t, alpha)[0]/p) @ frame(t, -alpha)[0].T


def categorical_check(t, alpha, h):
    p = curve(t)[0]
    n, speed, curvature = frame(t, alpha)
    d = coefficients(t, alpha, alpha, h)
    e = coefficients(t, -alpha, -alpha, h)
    omega = coefficients(t, alpha, 0, h)
    cubic = np.einsum('k,ik,jk,k->ij', n[0], n, n, 1/p**2)
    c = overlap(t, alpha)
    cdot = derivative(lambda x: overlap(x, alpha), t, h)/speed
    s = c @ cdot.T
    normality = comm(d, d.T)
    predicted = -alpha*comm(omega, cubic)
    errors = {
        'orthonormality': float(np.linalg.norm((n/p)@n.T-np.eye(2))),
        'omega_skew': float(np.linalg.norm(omega+omega.T)),
        'decomposition': float(np.linalg.norm(d-(omega-alpha*cubic/2))),
        'normality_identity': float(np.linalg.norm(normality-predicted)),
        'dual_relation': float(np.linalg.norm(d.T+c@e@c.T-s)),
        'overlap_ode': float(np.linalg.norm(cdot-d@c-c@e.T)),
        'source_skew': float(np.linalg.norm(s+s.T)),
        'source_tangent': float(np.linalg.norm(s[:, 0])),
    }
    if max(errors.values()) > 1e-7:
        raise AssertionError(errors)
    return dict(t=t, alpha=alpha, step=h, curvature=curvature,
                normality_norm=float(np.linalg.norm(normality)),
                commutator_norm=float(np.linalg.norm(comm(omega, cubic))),
                errors=errors, D=d.tolist(), E=e.tolist(), C=c.tolist(),
                S=s.tolist(), Omega=omega.tolist(), H=cubic.tolist())


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--out', default=str(Path(__file__).resolve().parents[2]/'Data/04_alpha_connections/results.json'))
    args = ap.parse_args()
    checks = [categorical_check(t, a, h) for t in [-.2, 0., .2]
              for a in [-1., 0., 1.] for h in [1e-4, 5e-5]]
    step_changes = []
    for first, second in zip(checks[::2], checks[1::2]):
        step_changes.append(float(np.linalg.norm(np.array(first['D'])-np.array(second['D']))))
    if max(step_changes) > 1e-7:
        raise AssertionError('Frame derivative did not stabilize')
    # Analytic nonmetric dually flat Euclidean R^2 example in the discussion note.
    a = 1.2
    d = np.array([[0., a], [a, 0.]])
    c = np.diag([1., -1.])
    exact_example = dict(a=a, D=d.tolist(), E=d.tolist(), C=c.tolist(),
                         normality_norm=float(np.linalg.norm(comm(d, d.T))),
                         dual_relation_norm=float(np.linalg.norm(d.T+c@d@c.T)))
    result = dict(date='2026-11-16', status='new focused numerical consistency checks',
                  environment=dict(python=platform.python_version(), numpy=np.__version__),
                  model='interior of the three-outcome categorical simplex',
                  convention='nabla^(alpha)=nabla^LC-alpha*Theta^sharp/2',
                  samples=checks, maximum_step_change=max(step_changes),
                  nonmetric_normal_example=exact_example)
    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(result, indent=2)+'\n')
    print(json.dumps(dict(checks=len(checks),
                         maximum_identity_error=max(max(x['errors'].values()) for x in checks),
                         maximum_step_change=max(step_changes),
                         alpha_zero_max_normality=max(x['normality_norm'] for x in checks if x['alpha']==0),
                         nonzero_alpha_normality_range=[min(x['normality_norm'] for x in checks if x['alpha']!=0),
                                                       max(x['normality_norm'] for x in checks if x['alpha']!=0)],
                         output=str(out)), indent=2))


if __name__ == '__main__':
    main()
