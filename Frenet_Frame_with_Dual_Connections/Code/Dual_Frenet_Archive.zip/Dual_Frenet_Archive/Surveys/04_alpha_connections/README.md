# Survey 04: information-geometric consistency checks

This focused calculation connects the normality assumption in the MathOverflow question to alpha connections. It was performed on 16 November 2026. It is a geometric diagnostic study, not a solution-counting survey.

Read [Methodology.md](Methodology.md) for the statistical model, frame construction, differentiation, residuals, and limitations. See [Results.md](Results.md), the general [information-geometry note](../../docs/Information_Geometry.md), and [Data/04_alpha_connections/](../../Data/04_alpha_connections/README.md).

From the archive root:

```bash
python Surveys/04_alpha_connections/run.py --out Reproduced/04/results.json
```

The nonzero-alpha categorical examples satisfy the dual frame identities but fail normality; they must not be counted as feasible normal-pair solutions. A separate nonmetric symmetric example demonstrates compatibility of positive curvature, duality, and normality.
