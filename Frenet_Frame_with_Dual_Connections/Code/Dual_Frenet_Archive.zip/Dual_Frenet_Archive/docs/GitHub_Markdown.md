# GitHub README math conventions

All README and note files in this archive follow these conventions.

1. Use GitHub inline math with dollar delimiters. Simple display equations can use double-dollar delimiters on separate lines. For matrices and other multiline displays, use fenced code blocks whose language is `math`, without enclosing dollar delimiters.
2. Avoid the operator-name macro rejected by the target renderer. Prefer built-in commands such as `\det`, `\min`, and `\sum`, or ordinary roman text with `\mathrm{...}`.
3. Put every subscript in braces, including single indices. Write `$N_{i}^{*}$`, `$D_{i,i+1}$`, `$S_{\perp}$`, and `$e_{1}$`.
4. For a named indexed object, put its whole name or index inside one brace group, or use a superscript for a label. Do not append a second subscript to an already subscripted expression without grouping it.
5. Keep labels and long explanations outside equations where possible. Avoid custom macros and renderer-specific extensions.
6. In this archive, write matrices with `\left(`, an `array` environment, and `\right)`. Separate columns with `&` and rows with `\cr`. This avoids relying on the parenthesized-matrix environment and doubled-backslash row commands that failed in the user's rendered copy. Put one row on each source line.

For example, the following is a fenced `math` block in the Markdown source:

```math
A=\left(\begin{array}{rr}
a&b\cr
c&d
\end{array}\right).
```

[GitHub's official guide](https://docs.github.com/en/get-started/writing-on-github/working-with-advanced-formatting/writing-mathematical-expressions) documents fenced `math` blocks and its use of MathJax. The [MathJax supported-command list](https://docs.mathjax.org/en/v3.2/input/tex/macros/index.html) includes `array` and `\cr`. Markdown processors can interpret backslashes before the math renderer sees them; the fenced format and explicit row command are the convention used here to address the reported failure.

The archive check includes both dollar-delimited and fenced math. It validates local Markdown links, brace structure, absence of the rejected macro, bracing of subscripts, and the matrix row convention above. Optional LaTeX compilation is attempted only when a complete local installation is available. These are source checks; they do not claim that the revised files were rendered on a live GitHub page.
