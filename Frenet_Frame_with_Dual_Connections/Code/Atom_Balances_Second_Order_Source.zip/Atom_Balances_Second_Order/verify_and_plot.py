"""Reproduce the finite-distribution checks and figures for the accompanying note.

Requirements: Python 3, numpy, matplotlib. All information values are in nats.
The six-variable hypergraph support is checked by exhaustive subset enumeration.
"""
from collections import defaultdict
from itertools import product
from pathlib import Path
import json
import math
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Circle, FancyArrowPatch, FancyBboxPatch

ROOT=Path(__file__).resolve().parent
FIG=ROOT/'figures'; FIG.mkdir(exist_ok=True)
b=math.log(2)
M=np.array([[1,0,0,0],[-1,1,0,0],[-1,0,1,0],[1,-1,-1,1]],float)
V=np.array([1,-1,-1,1.])
INK='#17374c';TEAL='#007c83';GOLD='#c78124';BLUE='#436eae';RED='#a53c53'
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':9,'axes.spines.top':False,
                     'axes.spines.right':False,'axes.labelcolor':INK,'text.color':INK,
                     'pdf.fonttype':42,'savefig.bbox':'tight'})

def near(a,c=0,tol=3e-9):
    assert np.max(np.abs(np.asarray(a)-np.asarray(c)))<tol,(a,c)

def H(p,idx):
    idx=tuple(sorted(set(idx)));q=defaultdict(float)
    for st,w in p.items():q[tuple(st[i] for i in idx)]+=w
    return -sum(v*math.log(v) for v in q.values() if v>0)

def MI(p,a,c,z=()):
    a,c,z=set(a),set(c),set(z)
    return H(p,a|z)+H(p,c|z)-H(p,a|c|z)-H(p,z)

def pid(p,k,t):
    a=MI(p,(k[0],),t);c=MI(p,(k[1],),t);r=min(a,c)
    return np.array([r,a-r,c-r,MI(p,k,t)-a-c+r])

def cpid(p,k,t,z):
    groups=defaultdict(dict);weights=defaultdict(float)
    for st,w in p.items():
        key=tuple(st[i] for i in z);groups[key][st]=w;weights[key]+=w
    ans=np.zeros(4)
    for key,law in groups.items():
        w=weights[key]
        if w:ans+=w*pid({st:q/w for st,q in law.items()},k,t)
    return ans

def phi(p):
    al=[[(0,),(1,)],[(0,)],[(1,)],[(0,1)]]
    be=[[(2,),(3,)],[(2,)],[(3,)],[(2,3)]]
    C=np.array([[min(MI(p,a,c) for a in aa for c in bb) for bb in be] for aa in al])
    return M@C@M.T,C

def pair_law(joint,a,c,offset):
    out=defaultdict(float)
    for st,w in joint.items():out[(st[a],st[c],st[a+offset],st[c+offset])]+=w
    return dict(out)

def residual_check(p):
    J,C=phi(p);hx=pid(p,(0,1),(0,1));hy=pid(p,(2,3),(2,3))
    G=cpid(p,(2,3),(2,3),(0,1));L=cpid(p,(0,1),(0,1),(2,3))
    gp=hy-J.sum(axis=0);lm=hx-J.sum(axis=1)
    kp=gp[0]-G[0];km=lm[0]-L[0];k=kp-km
    near(gp-G,kp*V);near(lm-L,km*V)
    near(hy-hx,J.sum(axis=0)-J.sum(axis=1)+G-L+k*V)
    near(G.sum(),H(p,(0,1,2,3))-H(p,(0,1)))
    near(L.sum(),H(p,(0,1,2,3))-H(p,(2,3)))
    assert min(np.r_[G,L])>-1e-9
    return J,hx,hy,G,L,k

def independent_law(probs,update):
    out=defaultdict(float)
    for x in product((0,1),repeat=len(probs)):
        w=math.prod(pr if xx else 1-pr for xx,pr in zip(x,probs))
        out[x+tuple(update(x))]+=w
    return dict(out)

def hbin(p):return -p*math.log(p)-(1-p)*math.log(1-p)

def arrow(ax,x,y,color=TEAL,rad=0,lw=1.5,shrinkA=14,shrinkB=14):
    ax.add_patch(FancyArrowPatch(x,y,arrowstyle='-|>',mutation_scale=13,color=color,
                                linewidth=lw,connectionstyle=f'arc3,rad={rad}',shrinkA=shrinkA,shrinkB=shrinkB))

def node(ax,xy,label,color=TEAL,r=.15):
    ax.add_patch(Circle(xy,r,facecolor='white',edgecolor=color,lw=1.6,zorder=4))
    ax.text(*xy,label,ha='center',va='center',zorder=5)

def verify():
    report={}
    rng=np.random.default_rng(16112026)
    for _ in range(100):
        ws=rng.uniform(.01,1,16);ws/=ws.sum()
        residual_check(dict(zip(product((0,1),repeat=4),ws)))
    report['residuals']='100 full-support stochastic laws: balance, positivity, and one-scalar redistribution checked'
    B=np.zeros((4,16))
    for a in range(4):
        for c in range(4):B[c,4*a+c]+=1;B[a,4*a+c]-=1
    K=B.T/8
    for _ in range(100):
        J=rng.normal(size=(4,4));d=J.sum(axis=0)-J.sum(axis=1)
        W=(J+J.T)/2;Z=(J-J.T)/2-(d[None,:]-d[:,None])/8
        near(Z.sum(axis=1),np.zeros(4));near(J,W+(d[None,:]-d[:,None])/8+Z)
    assert np.linalg.matrix_rank(B)==3
    assert np.linalg.matrix_rank(np.eye(16)-K@B)==13
    Brs=B[[0,3]];A=rng.normal(size=(16,2))*.03
    near(np.linalg.det(np.eye(16)-A@Brs),np.linalg.det(np.eye(2)-Brs@A))
    report['intrinsic_reduction']='Incidence rank 3; inherited-parametrization rank 13; 2x2 determinant reduction checked'
    # A physical three-cycle, and the exact local two-component atom balances.
    probs=np.array([.5,.1,.25]);copy=[]
    for t in range(7):
        law=independent_law(probs,lambda x:(x[2],x[0],x[1]));q=np.array([hbin(pr) for pr in probs])
        J,hx,hy,G,L,k=residual_check(pair_law(law,0,1,3))
        want=np.zeros((4,4));want[1,2]=q[0];near(J,want)
        near(G,[0,q[2],0,0]);near(L,[0,0,q[1],0])
        near(k,min(q[2],q[0])-min(q[0],q[1]))
        copy.append([*q,*hx,k]);probs=np.roll(probs,1)
    copy=np.array(copy);report['copy_cycle']='7 steps: exact unique-transfer atoms and all local residuals checked'
    # A reversible four-bit permutation with a four-phase positive PhiID cycle.
    dist={(0,0,u,w):.25 for u,w in product((0,1),repeat=2)}
    mode=[];jseq=[]
    for t in range(6):
        law=defaultdict(float);nxt=defaultdict(float)
        for x,w in dist.items():
            y=(x[2],x[0],x[3],x[1]);old=(2*x[0]+x[1],2*x[2]+x[3]);new=(2*y[0]+y[1],2*y[2]+y[3])
            law[old+new]+=w;nxt[y]+=w
        J,hx,hy,G,L,k=residual_check(dict(law))
        near(G,np.zeros(4));near(L,np.zeros(4));near(k)
        expected=np.zeros((4,4))
        for a,c in [[(2,0),(2,3)],[(0,1),(3,1)],[(1,0),(1,3)],[(0,2),(3,2)]][t%4]:expected[a,c]=b
        near(J,expected);mode.append(hx);jseq.append(J);dist=dict(nxt)
    mode=np.array(mode);jseq=np.array(jseq)
    near(mode[2:]-2*mode[1:-1]+mode[:-2],
         (jseq[1:-1]-jseq[:-2]).sum(axis=1)-(jseq[1:-1]-jseq[:-2]).sum(axis=2))
    near(mode[2:,0]-2*mode[1:-1,0]+mode[:-2,0],-2*np.diff(mode[:,0])[:-1])
    report['mode_cycle']='All 16 atoms checked over six phases; positive orbit, zero residuals, and curvature identity verified'
    # Six-component invertible XOR network, in order A,B,P,Q,K,L.
    F=[16,16|8,1|2,4,32,1];Q=[32,4|32,8,1|2,1,16];rows=[1<<i for i in range(6)]+F
    def rank(rr):
        basis={}
        for val in rr:
            while val:
                k=val.bit_length()-1
                if k in basis:val^=basis[k]
                else:basis[k]=val;break
        return len(basis)
    hs=[rank([rows[i] for i in range(12) if mask>>i&1]) for mask in range(4096)]
    def subs(mask):
        sm=mask
        while sm:yield sm;sm=(sm-1)&mask
    def co(args,ct):return sum((1 if sm.bit_count()%2 else -1)*(hs[sm|ct]-hs[ct]) for sm in subs(args))
    et={};er={}
    for bs in range(1,64):
        kb=qb=0
        for i in range(6):
            if bs>>i&1:kb|=F[i];qb|=Q[i]
        kb&=63^bs;qb&=63^bs
        for aa in subs(63^bs):
            v=co(aa|(bs<<6),bs);vr=co((aa<<6)|bs,bs<<6)
            if v and aa&~kb==0:et[aa,bs]=v
            if vr and aa&~qb==0:er[aa,bs]=vr
    rev={(bb,aa) for aa,bb in et}
    assert len(et)==10 and len(er)==10 and set(er)==rev and not(set(et)&rev)
    names='ABPQKL'
    lab=lambda mask:''.join(names[i] for i in range(6) if mask>>i&1)
    report['hypergraph_support']=[{'tail':lab(a),'head':lab(c),'weight_bits':w} for (a,c),w in et.items()]
    # Biased logical packets verify both synergy cuts and the selected hypercycle's update.
    logical=np.array([.1,.25,.5])
    for t in range(3):
        law={}
        for a,r,s,z,p,q in product((0,1),repeat=6):
            x=(a,a^z,p,q,r,s);y=(r,r^q,z,p,s,a)
            w=.125*math.prod(pr if val else 1-pr for val,pr in zip((z,p,q),logical));law[x+y]=w
        sv=np.array([hbin(pr) for pr in logical])
        near(MI(law,(0,),(8,),(2,)));near(MI(law,(1,),(8,),(2,)))
        near(MI(law,(0,1),(8,),(2,)),sv[0])
        near(MI(law,(3,),(6,),(0,1)));near(MI(law,(3,),(7,),(0,1)))
        near(MI(law,(3,),(6,7),(0,1)),sv[2]);near(MI(law,(2,),(9,),(3,)),sv[1])
        logical=np.roll(logical,1)
    report['hypercycle']='All 602 disjoint source/target choices checked at uniformity; biased selected synergy cuts verified over a period'
    # Finite observed block of stationary Bethe broadcast: parent, joint child block.
    bethe={(u,v,w,u):.125 for v,u,w in product((0,1),repeat=3)}
    J,hx,hy,G,L,k=residual_check(bethe)
    want=np.zeros((4,4));want[1,2]=b;near(J,want)
    near(G,[0,b,0,0]);near(L,[0,0,b,0]);near(k)
    report['bethe_broadcast']='Finite-block PhiID transfer b; innovation b; loss b; zero net redistribution checked'
    # Finite-depth independent splitting: two independent fragments and their tuple.
    split={(u,w,2*u+w):.25 for u,w in product((0,1),repeat=2)}
    near(MI(split,(0,),(2,)),b);near(MI(split,(1,),(2,)),b);near(MI(split,(0,1),(2,)),2*b)
    near(pid(split,(0,1),(2,)),[b,0,0,b])
    report['bethe_split']='Shannon child-fragment additivity checked; the MMI self-target allocation is reported explicitly'
    # Check the stated second differences in the formal near-zero Bethe closure.
    u=np.array([2.,1.3,.8,.5,.3]);vv=np.array([1.4,.9,.55,.3,.2])
    du=np.zeros(5);dv=np.zeros(5)
    du[1:]=u[:-1]-vv[1:]-u[1:];dv[1:]=.5*vv[:-1]-vv[1:]
    up=u+du;vp=vv+dv
    for d in range(2,5):
        near((up[d-1]-vp[d]-up[d])-du[d],u[d-2]-2*u[d-1]+u[d]-1.5*vv[d-1]+2*vv[d])
        near((.5*vp[d-1]-vp[d])-dv[d],.25*vv[d-2]-vv[d-1]+vv[d])
    report['bethe_formal_closure']='Both second-order recurrences verified algebraically on independent numerical data'
    return report,copy,mode,jseq

def figures(copy,mode,jseq):
    fig,ax=plt.subplots(1,3,figsize=(7.1,2.7),gridspec_kw={'width_ratios':[1,1.2,1]})
    pts=[(0,.85),(-.75,-.5),(.75,-.5)]
    for i in range(3):node(ax[0],pts[i],str(i+1));arrow(ax[0],pts[i],pts[(i+1)%3])
    ax[0].set_title('(a) Copying cycle');ax[0].text(0,-.95,r'$q_i=H(X_i)$',ha='center')
    p={'A':(-.8,.5),'B':(-.8,-.5),'P':(.85,.65),'Q':(.85,-.65)}
    for name,xy in p.items():node(ax[1],xy,name)
    hb=(-.05,.5);hf=(-.05,-.5)
    for tail in ('A','B'):arrow(ax[1],p[tail],hb,color=GOLD,lw=1.2,shrinkB=0)
    ax[1].plot(*hb,'D',color=GOLD,ms=5);arrow(ax[1],hb,p['P'],color=GOLD,shrinkA=0)
    arrow(ax[1],p['P'],p['Q']);arrow(ax[1],p['Q'],hf,color=GOLD,shrinkB=0)
    ax[1].plot(*hf,'D',color=GOLD,ms=5)
    for head in ('A','B'):arrow(ax[1],hf,p[head],color=GOLD,rad=.12 if head=='A' else 0,shrinkA=0)
    ax[1].set_title('(b) BF hypercycle');ax[1].text(0,-1.03,'Auxiliary key cycle omitted',ha='center',fontsize=7.5)
    tree={'p':(0,.9),'i':(0,.1),'c1':(-.65,-.7),'c2':(.65,-.7)}
    for label,xy in tree.items():node(ax[2],xy,{'p':r'$p(i)$','i':r'$i$','c1':r'$c_1$','c2':r'$c_2$'}[label])
    for a,c in [('p','i'),('i','c1'),('i','c2')]:arrow(ax[2],tree[a],tree[c])
    ax[2].set_title('(c) Bethe bulk');ax[2].text(0,-1.03,'One parent, two children',ha='center',fontsize=7.5)
    for a in ax:a.set_xlim(-1.15,1.15);a.set_ylim(-1.15,1.2);a.set_aspect('equal');a.axis('off')
    fig.tight_layout(w_pad=2);fig.savefig(FIG/'topologies.pdf');plt.close(fig)
    fig,ax=plt.subplots(1,2,figsize=(7.1,2.85))
    t=np.arange(len(copy))
    for i in range(3):ax[0].plot(t,copy[:,i]/b,'o-',label=fr'$q_{i+1}$')
    ax[0].set(xlabel='Step',ylabel='Information / bit',title='Physical edge flows rotate')
    for i,label in enumerate(['R','U_1','U_2','S']):ax[1].plot(t,copy[:,3+i]/b,'o-',label=fr'${label}$')
    ax[1].set(xlabel='Step',title='Local pair information state')
    for a in ax:a.legend(frameon=False,ncol=2);a.grid(alpha=.18)
    fig.tight_layout();fig.savefig(FIG/'copy_cycle.pdf');plt.close(fig)
    fig,ax=plt.subplots(1,2,figsize=(7.1,3.0),gridspec_kw={'width_ratios':[1,1.35]})
    for i,label in enumerate(['R','U_1','U_2','S']):ax[0].plot(np.arange(5),mode[:5,i]/b,'o-',label=fr'${label}$')
    ax[0].set(xlabel='Step',ylabel='Information / bit',title='Reversible four-phase orbit');ax[0].legend(frameon=False,ncol=2);ax[0].grid(alpha=.18)
    entries=[(2,0),(2,3),(0,1),(3,1),(1,0),(1,3),(0,2),(3,2)]
    data=np.array([[J[a,c]/b for a,c in entries] for J in jseq[:4]])
    ax[1].imshow(data,cmap='Blues',vmin=0,vmax=1,aspect='auto')
    labs=['U2-R','U2-S','R-U1','S-U1','U1-R','U1-S','R-U2','S-U2']
    ax[1].set_xticks(range(8),labs,rotation=55,ha='right',fontsize=8)
    ax[1].set_yticks(range(4),range(4));ax[1].set(ylabel='Phase',title='Blue entries = one bit')
    fig.tight_layout();fig.savefig(FIG/'mode_cycle.pdf');plt.close(fig)
    fig,ax=plt.subplots(1,2,figsize=(7.1,2.85))
    ts=np.arange(16);depth=np.arange(6)
    def ent(s):return .35+.55*np.exp(-((s-4)/2)**2)
    heat=np.array([[ent(t-d) for t in ts] for d in depth])
    im=ax[0].imshow(heat,origin='upper',aspect='auto',cmap='viridis',extent=[-.5,15.5,5.5,-.5],vmin=0,vmax=1)
    ax[0].set(xlabel='Step',ylabel='Depth',title='Broadcast entropy pulse')
    fig.colorbar(im,ax=ax[0],label='Information / bit',fraction=.05)
    d=np.arange(7);ax[1].plot(d,np.ones_like(d),'o-',label='Broadcast per child')
    ax[1].plot(d,2.**(-d),'s-',label='Additive half-profile')
    ax[1].set(xlabel='Depth',ylabel='Normalized information',title='Copying versus splitting')
    ax[1].legend(frameon=False,fontsize=7.5);ax[1].grid(alpha=.18)
    fig.tight_layout();fig.savefig(FIG/'bethe_profiles.pdf');plt.close(fig)

if __name__=='__main__':
    report,copy,mode,jseq=verify();figures(copy,mode,jseq)
    (ROOT/'verification_results.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))
