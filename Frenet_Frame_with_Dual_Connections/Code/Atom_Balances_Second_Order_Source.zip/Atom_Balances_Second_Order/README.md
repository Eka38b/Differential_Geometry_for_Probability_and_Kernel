# Information-Atom Balances and Intrinsic Second-Order Reduction

Note, 16 November 2026. No author is designated.

## Build the PDF

Use a standard TeX Live installation with pdflatex and the packages listed in the main source. From this directory run:

    pdflatex Atom_Balances_Second_Order.tex
    pdflatex Atom_Balances_Second_Order.tex

The bibliography is included directly; BibTeX is not required. The figures are included as vector PDFs.

## Reproduce the finite examples and figures

Requirements: Python 3, NumPy, Matplotlib.

    python3 verify_and_plot.py

This recalculates the checks, replaces verification_results.json, and regenerates the four figures. Information is computed in nats; figures divide by ln(2) to show bits. The hypergraph support uses binary ranks and exhaustive subset enumeration, rather than stochastic sampling.

## Mathematical scope

The main state is an explicitly defined self-target PID. The example measures are identified, including their differing redundancy/synergy allocations. Double-MMI atoms need not be nonnegative in general. The second-order elimination theorem needs an independently derived atom equation. The formal Bethe flow closure is separated from the finite-probability examples. Strong blocking for the six-bit hypercycle is verified at the uniform ensemble and is not asserted for its biased extension.

The source preprint is referred to by its title, A Directed-Hypergraph Representation of Higher-Order Information Flows. The note contains 15 background/source references with clickable DOI or arXiv links where available.
